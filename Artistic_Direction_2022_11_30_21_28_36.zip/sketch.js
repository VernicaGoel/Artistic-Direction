let mySound; let t = 0;  
function preload() {
  soundFormats('mp3');
  mySound = loadSound('song/achyutam-keshavam');
}

function setup() {
  let cnv = createCanvas(windowWidth, windowHeight);
  noStroke();
  fill("lightblue");
  cnv.mousePressed(canvasPressed);
  background(220);
  text('tap here to play', 10, 20);
}

function canvasPressed() {
  mySound.play();

  
}

function draw() {
  background(10, 10); 
  
  for (let x = 0; x <= width; x = x + 100) {
    for (let y = 0; y <= height; y = y + 100) {
      
      const xAngle = map(mouseX, 0, width, 5 * PI, 10 * PI, true);
      const yAngle = map(mouseY, 0, height, 5 * PI, 10 * PI, true);
      
      const angle = xAngle * (x / width) + yAngle * (y / height);

      const aX = x + 50 * sin(2 * PI * t + angle);
      const bY = y + 50 * cos(2 * PI * t + angle);

      ellipse(aX, bY, 5); 
    }
  }

  t = t + 0.01; 
}